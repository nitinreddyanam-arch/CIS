"""
Rigid registration helpers: point-set registration, frame averaging and
marker-body refinement.
"""

from typing import List

import numpy as np

from data_types.nominal_types import vct3, Rot, Frame

from assignments.assignment1.src.tracker import Tracker
from ..simulation import PlacedBody, sample_marker_bodies, most_recent_observed_markers, update_marker_body

def _as_array(points) -> np.ndarray:
    """List of vct3 (or uvct3, which wraps one in .p) -> N x 3 array."""
    rows = []
    for q in points:
        q = q.p if hasattr(q, "p") and not isinstance(q, vct3) else q
        rows.append(np.asarray(q.vec, dtype=np.float64).ravel())
    return np.array(rows).reshape(-1, 3)


def _rotation_from_matrix(M: np.ndarray) -> np.ndarray:
    """Nearest proper rotation to M (Frobenius norm), via SVD with the determinant fix."""
    U, _, Vt = np.linalg.svd(M)
    d = np.sign(np.linalg.det(U @ Vt))
    return U @ np.diag([1.0, 1.0, d]) @ Vt
    
def register_points(a: List[vct3], b: List[vct3]) -> Frame:
    """
    TODO: implement (your own -- do not call the simulator's solver).

    Rigid point-set registration: find the least-squares Frame F such that
    F * a[i] ~= b[i] for every corresponding pair. Think about what happens
    with fewer than 3 points, with collinear points, and with a reflection.

    input:
        a - points in the source frame (e.g. a marker body's local layout)
        b - the same points observed in the target frame, same order
    output: Frame mapping a -> b
    """
    A, B = _as_array(a), _as_array(b)
    if len(A) != len(B):
        raise ValueError(f"register_points: {len(A)} source points but {len(B)} target points")
    if len(A) < 3:
        raise ValueError(f"register_points: need at least 3 point pairs, got {len(A)}")

    a_bar, b_bar = A.mean(axis=0), B.mean(axis=0)
    A_c, B_c = A - a_bar, B - b_bar

    spread = np.linalg.svd(A_c, compute_uv=False)
    if spread[1] <= 1e-9 * max(spread[0], 1.0):
        raise ValueError("register_points: source points are collinear; rotation about that line is undetermined")

    H = A_c.T @ B_c                         # H = sum_k a~_k b~_k^T
    U, _, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))  # -1 would be a reflection
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    p = b_bar - R @ a_bar
    return Frame(Rot(matrix=R), vct3(p))


def average_frames(frames: List[Frame]) -> Frame:
    """
    TODO: implement.

    Average of several noisy estimates of the same Frame. Rotations cannot
    simply be averaged element-wise -- the result must be a proper
    rotation matrix.

    input:
        frames - List[Frame], all estimates of the same transform
    output: the averaged Frame
    """
    if len(frames) == 0:
        raise ValueError("average_frames: no frames to average")
    R_mean = np.mean([F.R.matrix for F in frames], axis=0)
    p_mean = np.mean([np.asarray(F.p.vec, dtype=np.float64).ravel() for F in frames], axis=0)
    return Frame(Rot(matrix=_rotation_from_matrix(R_mean)), vct3(p_mean))


def refine_marker_body(trk: Tracker, placed: PlacedBody, n_readings: int = 30) -> List[vct3]:
    """
    TODO: implement.

    "It is possible to improve your estimate of a_m,k through a calibration
    process involving multiple observations of the marker body using the
    tracking camera and then averaging them."

    Take n_readings SampleMarkerBodies readings, use
    most_recent_observed_markers(...) plus your register_points to bring
    each reading's b_m,k back into the body's own frame, average, and push
    the result into the body with update_marker_body(...). Note that each
    reading costs delta_t_samp of simulated time, and that the tracker
    jiggles between readings.

    input:
        trk - Tracker the body is tracked by
        placed - PlacedBody whose body's nominal marker positions should be refined
        n_readings - number of readings to average
    output: the new List[vct3] of marker positions (also stored on the body)
    """
    body = placed.body
    layout = list(body.nominal_marker_positions)
    local_sum, n_used = np.zeros((len(layout), 3)), 0
    for _ in range(n_readings):
        sample_marker_bodies(trk)
        observed = most_recent_observed_markers(body)
        if observed is None:          # not visible in this reading
            continue
        observed_points = [vct3(row) for row in _as_array(observed)]
        F_inv = register_points(layout, observed_points).inv()
        local_sum += _as_array([F_inv * q for q in observed_points])
        n_used += 1
    if n_used == 0:
        raise ValueError(f"refine_marker_body: body {body.name!r} was never visible")
    refined = [vct3(row) for row in local_sum / n_used]
    update_marker_body(body, refined)
    return refined
