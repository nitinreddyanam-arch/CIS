"""
Pose-error metrics used to report calibration accuracy.
"""

from typing import Dict, Sequence, Tuple

import numpy as np

from data_types.nominal_types import Frame


def frame_error(F_a: Frame, F_b: Frame) -> Tuple[float, float]:
    """
    TODO: implement.

    The mismatch between two frames is defined as
    dF = F_a^-1 F_b ~= Frame(I + sk(alpha), epsilon); report its size.

    input:
        F_a - reference Frame (e.g. ground truth)
        F_b - Frame to compare (e.g. your prediction)
    output:
        (angle_rad, dist_mm) - ||alpha|| (the rotation angle of dF.R) and
            ||epsilon|| (the norm of dF.p)
    """
    dF = F_a.inv() * F_b
    R = dF.R.matrix
    # rotation angle from the skew part (sin) and the trace (cos): accurate for small and large angles alike
    skew = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    sin_angle = 0.5 * np.linalg.norm(skew)
    cos_angle = 0.5 * (np.trace(R) - 1.0)
    angle_rad = float(np.arctan2(sin_angle, cos_angle))
    dist_mm = float(np.linalg.norm(dF.p.vec))
    return angle_rad, dist_mm


def summarize_errors(errors: Sequence[Tuple[float, float]]) -> Dict[str, float]:
    """
    TODO: implement.

    input:
        errors - list of (angle_rad, dist_mm) pairs from frame_error
    output:
        dict with at least the keys
            n, rms_angle, max_angle, rms_pos, max_pos
    """
    errors = np.asarray(errors, dtype=np.float64).reshape(-1, 2)
    if len(errors) == 0:
        raise ValueError("summarize_errors: no errors to summarize")
    angles, dists = errors[:, 0], errors[:, 1]
    return {
        "n": int(len(errors)),
        "rms_angle": float(np.sqrt(np.mean(angles ** 2))),
        "mean_angle": float(np.mean(angles)),
        "max_angle": float(np.max(angles)),
        "rms_pos": float(np.sqrt(np.mean(dists ** 2))),
        "mean_pos": float(np.mean(dists)),
        "max_pos": float(np.max(dists)),}