from typing import Dict, Optional
 
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
 
from data_types.nominal_types import vct3, Rot, Frame
from uncertainty_networks.se3 import log_so3
 
from ..robot import Robot
from .workflow import CalibrationData
 
 
class ImprovedKinematics(Robot):
    """
    A Robot whose fwd_kins / inv_kins use the calibrated error model
 
        theta*_k = theta_k + offset_k + sum_j c_k,j (theta_k / s_k)^j      (all six joints)
        d*_k     = Exp(phi_k) d_k,  phi_k in the plane perpendicular to d_k   (k = 2..6)
        F*_we    = F_WE [Exp(alpha_we), eps_we]
        F_X      = F_X_init [Exp(alpha_X), eps_X]    (robot base in the tracker frame)
 
    Parameter vector (all zero = the nominal robot at F_X_init):
        params[0:6]    alpha_X, eps_X     base frame correction
        params[6:15]   tilts              d_2: 1 component (about z); d_3, n_4, n_5, n_6: 2 each
        params[15:21]  alpha_we, eps_we   tool frame correction
        params[21:]    c_k,j              per-joint distortion polynomial, joint-major, j = 1..n_poly
 
    The offsets offset_k are not fitted: they come from HomeRobot()
    (workflow.measure_home_offsets). For joints 1-3 an offset is the same as
    a shift of the base, so the fit could not separate them; for joints 4-6
    it trades off against the tilts and the tool frame. s_k is the joint's
    largest travel (600, 300, 600 mm, 0.75 pi, 0.75 pi, pi rad), so each
    c_k,j is the distortion in mm or rad at the end of travel.
    """
 
    # Directions in which each axis may tilt (unit vectors perpendicular to the nominal axis).
    # d_1 is exact. d_2 tilts only about z (towards d_1): its tilt about d_1 = x is the same as
    # a rotation of the whole base about d_1, which the base frame F_X already contains.
    TILT_DIRECTIONS = {1: [np.array([0., 0., 1.])],
                       2: [np.array([1., 0., 0.]), np.array([0., 1., 0.])],
                       3: [np.array([0., 1., 0.]), np.array([0., 0., 1.])],
                       4: [np.array([1., 0., 0.]), np.array([0., 0., 1.])],
                       5: [np.array([1., 0., 0.]), np.array([0., 1., 0.])]}
    N_TILT = 9
 
    def __init__(self, robot: Robot, F_X_init: Frame, joint_offsets=None, n_poly: int = 2):
        super().__init__(robot.name + "_improved", robot.F_rob, robot.theta_min, robot.theta_max,
                         robot.t_settle, robot.theta_dot_max, robot.theta_ddot_max)
        self.F_X_init = F_X_init  # starting estimate of the base frame (from the nominal fit)
        self.joint_offsets = np.zeros(6) if joint_offsets is None else np.asarray(joint_offsets, dtype=np.float64).reshape(6)
        self.n_poly = n_poly      # degree of the per-joint distortion polynomial
        self.joint_span = np.maximum(np.abs(self.theta_min), np.abs(self.theta_max))
        self.params = self.initial_params()
 
    def initial_params(self) -> np.ndarray:
        """
        output: the parameter vector that makes this model identical to the
                nominal kinematics with base frame F_X_init (all zeros):
                6 base + 9 tilts + 6 tool + 6 * n_poly joint-distortion values
        """
        return np.zeros(6 + self.N_TILT + 6 + 6 * self.n_poly)
 
    def base_frame(self, params: Optional[np.ndarray] = None) -> Frame:
        """
        output: F_X (robot base relative to the tracker) for params (default:
                self.params): F_X_init * [Exp(alpha_X), eps_X]
        """
        params = self.params if params is None else np.asarray(params, dtype=np.float64)
        R = Rotation.from_rotvec(params[0:3]).as_matrix()
        return self.F_X_init * Frame(Rot(matrix=R), vct3(params[3:6]))
 
    def fwd_kins(self, theta, params: Optional[np.ndarray] = None) -> Frame:
        """
        ImprovedFwdKins(theta).
 
        Applies, in order: the joint correction (HomeRobot offset plus fitted
        polynomial) to the encoder values; the tilted axes d*_k = Exp(phi_k) d_k;
        then F_ee = Trans(sum theta*_k d*_k) F_CW R(n*_4, theta*_4) R(n*_5, theta*_5)
        R(n*_6, theta*_6) F*_we.
 
        input: theta - 6 encoder joint values; params - defaults to self.params
        output: F_ee relative to the robot base frame
        """
        params = self.params if params is None else np.asarray(params, dtype=np.float64)
        theta = np.asarray(theta, dtype=np.float64).reshape(6)
        tilts = params[6:6 + self.N_TILT]
        xi_we = params[6 + self.N_TILT:12 + self.N_TILT]
        poly = params[12 + self.N_TILT:].reshape(6, self.n_poly)
 
        # theta* = theta + offset + sum_j c_kj (theta / span)^j
        u = theta / self.joint_span
        th = theta + self.joint_offsets + sum(poly[:, j - 1] * u ** j for j in range(1, self.n_poly + 1))
 
        # tilted axes d*_1..3, n*_4..6
        d, i = [np.asarray(self.AXES[0].vec, dtype=np.float64).ravel()], 0
        for k in range(1, 6):
            phi = np.zeros(3)
            for direction in self.TILT_DIRECTIONS[k]:
                phi += tilts[i] * direction
                i += 1
            d.append(Rotation.from_rotvec(phi).apply(np.asarray(self.AXES[k].vec, dtype=np.float64).ravel()))
 
        p_c = th[0] * d[0] + th[1] * d[1] + th[2] * d[2]
        R_w = (Rotation.from_rotvec(th[3] * d[3]) * Rotation.from_rotvec(th[4] * d[4])
               * Rotation.from_rotvec(th[5] * d[5])).as_matrix()
        R_we = Rotation.from_rotvec(xi_we[:3]).as_matrix()          # F_WE has identity rotation
        p_we = np.asarray(self.F_WE.p.vec, dtype=np.float64).ravel() + xi_we[3:]
        p_cw = np.asarray(self.F_CW.p.vec, dtype=np.float64).ravel()
        return Frame(Rot(matrix=R_w @ R_we), vct3(p_c + p_cw + R_w @ p_we))
 
    def predict_in_tracker(self, theta, params: Optional[np.ndarray] = None) -> Frame:
        """The end-effector pose in the tracker frame: base_frame * fwd_kins."""
        return self.base_frame(params) * self.fwd_kins(theta, params)
 
    def inv_kins(self, F: Frame, seed=None, tol: float = 1e-10, max_iter: int = 50) -> np.ndarray:
        """
        ImprovedInvKins(F) -- provided.
 
        There is no closed form once the axes are tilted, so this iterates
        on your fwd_kins: both nominal wrist branches (Robot.inv_kins'
        closed form) are refined with damped Gauss-Newton / Levenberg-
        Marquardt steps on the pose error [alpha; epsilon] of
        fwd_kins(theta)^-1 F, and the in-limit solution nearest `seed`
        (default: the current command) is returned. Works as soon as your
        fwd_kins does.
 
        input: F - desired F_ee relative to the robot base frame
        output: theta with fwd_kins(theta) ~= F; raises ValueError if no
                branch satisfies the joint limits
        """
        seed = self.theta_cmd if seed is None else np.asarray(seed, dtype=np.float64).reshape(6)
        p_w = F.p - F.R * self.F_WE.p - self.F_CW.p   # nominal wrist center -> seeds for the linear joints
        step_max = np.array([50.0] * 3 + [0.3] * 3)
        h = np.array([1e-3] * 3 + [1e-6] * 3)
 
        def pose_delta(theta):
            dF = self.fwd_kins(theta).inv() * F
            return np.concatenate([log_so3(dF.R.matrix), dF.p.vec.ravel()])
 
        candidates = []
        for wrist in self.wrist_solutions(F.R):
            theta = np.concatenate([[p_w.x, p_w.y, p_w.z], wrist])
            lam, delta = 1e-4, pose_delta(theta)
            for _ in range(max_iter):
                cost = float(delta @ delta)
                if np.sqrt(cost) < tol:
                    break
                J = np.zeros((6, 6))
                for k in range(6):
                    th = theta.copy()
                    th[k] += h[k]
                    J[:, k] = (pose_delta(th) - delta) / h[k]
                while True:  # Levenberg-Marquardt: shrink the step until the cost decreases
                    JtJ = J.T @ J
                    step = -np.linalg.solve(JtJ + lam * np.diag(np.diag(JtJ) + 1e-12), J.T @ delta)
                    trial = theta + np.clip(step, -step_max, step_max)
                    delta_trial = pose_delta(trial)
                    if float(delta_trial @ delta_trial) < cost or lam > 1e6:
                        theta, delta, lam = trial, delta_trial, max(lam / 10.0, 1e-12)
                        break
                    lam *= 10.0
            theta[3] = (theta[3] + np.pi) % (2 * np.pi) - np.pi
            theta[5] = (theta[5] + np.pi) % (2 * np.pi) - np.pi
            if self.within_limits(theta):
                candidates.append(theta)
        if not candidates:
            raise ValueError(f"inv_kins: no joint solution within limits for {F!r}")
        return min(candidates, key=lambda th: float(np.linalg.norm(th - seed)))
 
    # ------------------------------------------------------------------ fitting
 
    def residuals(self, params: np.ndarray, data: CalibrationData,
                  sigma_rot: float = 5e-4, sigma_pos: float = 0.03) -> np.ndarray:
        """
        Weighted pose residuals of the model against the observations.
 
        For every sample, dF = (F_X F_ee(theta_j))^-1 F_obs,j; the residual is
        [log(dF.R) / sigma_rot, dF.p / sigma_pos], so rotation and translation
        are weighed by their measurement noise (defaults: one reading of the
        14-marker body, about 4.4e-4 rad per axis and 0.03 mm per axis).
 
        input: params - candidate parameter vector; data - CalibrationData
        output: flat residual vector, 6 per sample
        """
        out = []
        for theta, F_obs in zip(data.thetas, data.frames):
            dF = self.predict_in_tracker(theta, params).inv() * F_obs
            out.append(np.concatenate([np.asarray(log_so3(dF.R.matrix)).ravel() / sigma_rot,
                                       np.asarray(dF.p.vec, dtype=np.float64).ravel() / sigma_pos]))
        return np.concatenate(out)
 
    def fit(self, data: CalibrationData, sigma_rot: float = 5e-4, sigma_pos: float = 0.03, **kwargs):
        """
        Non-linear least squares over all parameters (scipy least_squares,
        Levenberg-Marquardt, finite-difference Jacobian), starting from the
        current params. Sets self.params.
 
        output: dict with the final RMS residuals (rad, mm), iterations and status
        """
        if len(data) * 6 < len(self.params):
            raise ValueError(f"fit: {len(data)} samples give fewer equations than {len(self.params)} parameters")
        result = least_squares(self.residuals, self.params, args=(data, sigma_rot, sigma_pos),
                               method="lm", x_scale="jac", **kwargs)
        self.params = result.x
        r = result.fun.reshape(-1, 6)
        return {"rms_rot_rad": float(np.sqrt(np.mean(r[:, :3] ** 2)) * sigma_rot),
                "rms_pos_mm": float(np.sqrt(np.mean(r[:, 3:] ** 2)) * sigma_pos),
                "n_samples": len(data), "n_params": len(self.params),
                "evaluations": int(result.nfev), "status": result.message}
 
    def jacobian_rank_report(self, data: CalibrationData, params: Optional[np.ndarray] = None,
                             rel_tol: float = 1e-6) -> dict:
        """
        Singular values of the weighted residual Jacobian (central differences).
 
        A singular value below rel_tol times the largest marks a parameter
        direction the data cannot determine; the parameters with the largest
        weight in that direction are listed.
 
        output: dict with rank, n_params, singular_values, condition number
                and, for each weak direction, the parameters it involves
        """
        params = self.params if params is None else np.asarray(params, dtype=np.float64)
        J = np.zeros((len(data) * 6, len(params)))
        h = 1e-6
        for i in range(len(params)):
            up, down = params.copy(), params.copy()
            up[i] += h
            down[i] -= h
            J[:, i] = (self.residuals(up, data) - self.residuals(down, data)) / (2 * h)
        _, sv, Vt = np.linalg.svd(J, full_matrices=False)
        rank = int(np.sum(sv > rel_tol * sv[0]))
        names = (["alpha_X_x", "alpha_X_y", "alpha_X_z", "eps_X_x", "eps_X_y", "eps_X_z"]
                 + [f"tilt_{k + 1}_{'xyz'[int(np.argmax(u))]}" for k, us in self.TILT_DIRECTIONS.items() for u in us]
                 + ["alpha_we_x", "alpha_we_y", "alpha_we_z", "eps_we_x", "eps_we_y", "eps_we_z"]
                 + [f"c_{k + 1}_{j}" for k in range(6) for j in range(1, self.n_poly + 1)])
        weak = []
        for idx in range(rank, len(sv)):
            top = np.argsort(-np.abs(Vt[idx]))[:3]
            weak.append({"singular_value": float(sv[idx]), "params": [names[t] for t in top]})
        return {"rank": rank, "n_params": len(params), "singular_values": sv,
                "condition": float(sv[0] / sv[-1]) if sv[-1] > 0 else float("inf"), "weak_directions": weak}
 
    # ------------------------------------------------------------------ reporting
 
    def parameters_report(self) -> Dict[str, np.ndarray]:
        """
        The calibrated parameters in physical terms.
 
        axes are the tilted axes in the robot base frame; because the base
        frame F_X is itself fitted, they are only defined up to that frame
        (the gauge), so the angles between axes are the meaningful
        comparison. joint_offset is the HomeRobot value delta_theta_sys(0);
        joint_scale is the fitted linear coefficient per mm or rad of travel.
        """
        tilts = self.params[6:6 + self.N_TILT]
        xi_we = self.params[6 + self.N_TILT:12 + self.N_TILT]
        poly = self.params[12 + self.N_TILT:].reshape(6, self.n_poly)
        nominal = np.array([np.asarray(a.vec, dtype=np.float64).ravel() for a in self.AXES])
        d, i = [nominal[0]], 0
        for k in range(1, 6):
            phi = np.zeros(3)
            for direction in self.TILT_DIRECTIONS[k]:
                phi += tilts[i] * direction
                i += 1
            d.append(Rotation.from_rotvec(phi).apply(nominal[k]))
        d = np.array(d)
        tilt_angles = np.degrees(np.arccos(np.clip(np.sum(d * nominal, axis=1), -1, 1)))
        pairs = {"d1-d2": (0, 1), "d1-d3": (0, 2), "d2-d3": (1, 2), "n4-n5": (3, 4), "n5-n6": (4, 5), "n4-n6": (3, 5)}
        angles = {k: float(np.degrees(np.arccos(np.clip(abs(d[a] @ d[b]), -1, 1)))) for k, (a, b) in pairs.items()}
        return {
            "axes": d, "axis_tilt_deg": tilt_angles, "axis_angles_deg": angles,
            "joint_offset": self.joint_offsets.copy(),
            "joint_scale": poly[:, 0] / self.joint_span,
            "joint_poly": poly.copy(),
            "F_we_twist": np.asarray(xi_we, dtype=np.float64).copy(),
            "F_X": self.base_frame(),
        }