"""
Data-collection workflow: which robot poses to visit, how to read them, and
how to register the robot base to the tracker.
"""

from dataclasses import dataclass, field
from typing import List

import numpy as np

from data_types.nominal_types import vct3, Frame

from ..robot import Robot
from assignments.assignment1.src.tracker import Tracker
from ..simulation import PlacedBody
from ..simulation import PlacedBody, sample_marker_bodies, clock, constants
from .registration import average_frames


@dataclass
class CalibrationData:
    """One calibration data set.

    thetas[j] is the commanded (encoder) joint vector and frames[j] the
    calibration body's observed pose relative to the tracker, F_ee,j (this
    handout's tracker has no jiggle, so the tracker frame is a fixed
    reference). t_collect is the simulated time the collection took.
    """
    thetas: List[np.ndarray] = field(default_factory=list)
    frames: List[Frame] = field(default_factory=list)
    t_collect: float = 0.0

    def __len__(self):
        return len(self.thetas)


def measure_home_offsets(rob: Robot, n_homings: int = 5) -> np.ndarray:
    """
    TODO: implement.

    HomeRobot() drives the robot to theta* = 0 and returns the encoder
    values there, i.e. -delta_theta_sys(home) - delta_theta_rnd. Repeat it
    and average to estimate the systematic joint offsets at home (after the
    first homing the move is tiny, so each repeat costs about t_settle).

    input:
        rob - the robot (rob.home_robot())
        n_homings - how many homings to average
    output: estimated delta_theta_sys at home, np.ndarray of 6
    """
    if n_homings < 1:
        raise ValueError("measure_home_offsets: n_homings must be at least 1")
    encoders = np.array([rob.home_robot() for _ in range(n_homings)])
    return -encoders.mean(axis=0)

    
# this should contain a desired accuracy which will affect the number of calibration poses
def plan_calibration_poses(rob: Robot, trk: Tracker, mbee_local_positions: List[vct3], desired_accuracy: float,
                           n_stops_linear: int = 7, n_stops_wrist: int = 7,
                           wrist_reach=(1.5, 1.5, 2.2), safety: float = 3.0, **kwargs) -> List[np.ndarray]:
    """
    TODO: implement -- this is a design task.

    Choose the joint vectors the robot will visit during calibration to reach the desired accuracy. Every
    parameter of your kinematic model must be excited by the data (axis
    tilts need travel along each axis; the wrist axes and F_we need wrist
    rotations; the joint distortion needs several stops along each joint),
    every pose must keep all calibration-body markers inside the tracker's
    viewing volume (Tracker.is_visible, using the nominal rob.F_rob and
    rob.fwd_kins -- they are only tens of mm off), and the order of the
    poses determines the motion time. The wrist moves at 0.1 rad/s: a pi/2
    turn costs ~16 s.

    The handout's method 1: decide how closely spaced the samples along an
    axis must be from the error bounds (delta_sys^trk, omega_sys^trk,
    delta_sys^rob, omega_sys^rob), then sweep each axis in turn from the
    home position. Joints 1-3 are decoupled from 4-6.

    input:
        rob - the Robot (nominal kinematics + limits)
        trk - the Tracker (for visibility checks)
        mbee_local_positions - the calibration body's marker layout a*_k
        desired_accuracy - target RMS orientation error in rad (the limiting
            metric); use it to size the plan -- how many distinct poses and
            how often each is read (a pose listed twice in a row is
            re-commanded and re-read, costing only t_settle + delta_t_samp)
        kwargs - whatever your design needs (grid sizes, margins, ...)
    output: ordered List of joint vectors (np.ndarray of 6)
    """
    A = np.array([np.asarray(a.vec, dtype=np.float64).ravel() for a in mbee_local_positions])
    A = A - A.mean(axis=0)
    J = sum(np.dot(a, a) * np.eye(3) - np.outer(a, a) for a in A)
    sigma_reading = constants.SENSOR_NOISE_STD * np.sqrt(np.max(np.linalg.eigvalsh(np.linalg.inv(J))))
    n_wrist = int(np.ceil(12.0 * (safety * sigma_reading / desired_accuracy) ** 2))
    readings_per_stop = max(1, int(np.ceil(n_wrist / n_stops_wrist)))
 
    # stops per joint: linear joints over full travel, wrist joints over +-reach
    sweeps = [(k, np.linspace(rob.theta_min[k], rob.theta_max[k], n_stops_linear), 1) for k in range(3)]
    for k, reach in zip(range(3, 6), wrist_reach):
        reach = min(reach, rob.theta_max[k], -rob.theta_min[k])
        sweeps.append((k, np.linspace(-reach, reach, n_stops_wrist), readings_per_stop))
 
    # home -> each stop of one joint (re-commanded readings_per_stop times) -> home
    poses = [np.zeros(6)]
    for k, values, n_rep in sweeps:
        for v in values:
            theta = np.zeros(6)
            theta[k] = v
            poses += [theta.copy() for _ in range(n_rep)]
        poses.append(np.zeros(6))
 
    for theta in poses:
        if not rob.within_limits(theta):
            raise ValueError(f"plan_calibration_poses: {theta} violates the joint limits")
        F_ee_world = rob.F_rob * rob.fwd_kins(theta)
        if not trk.is_visible([F_ee_world * a for a in mbee_local_positions]):
            raise ValueError(f"plan_calibration_poses: calibration body not visible at {theta}")
    return poses


def collect_calibration_data(rob: Robot, trk: Tracker, mbee_placed: PlacedBody,
                             thetas: List[np.ndarray], repeats: int = 1) -> CalibrationData:
    """
    TODO: implement.

    Visit each joint vector with rob.move_joints, read the calibration body
    with sample_marker_bodies and store its frame relative to the tracker.
    Decide what to do when the body is not visible (None), and whether/how
    to use repeats (re-sampling costs 0.03 s; re-commanding the same pose
    costs t_settle and re-rolls the joint repeatability noise).

    input:
        rob, trk - robot and tracker
        mbee_placed - the robot calibration body (attached)
        thetas - joint vectors to visit, in order
        repeats - readings per pose
    output: CalibrationData
    """
    data = CalibrationData()
    t_start = clock.elapsed
    name = mbee_placed.body.name
    for theta in thetas:
        theta = np.asarray(theta, dtype=np.float64).reshape(6)
        rob.move_joints(theta)
        for _ in range(repeats):
            observed = sample_marker_bodies(trk).get(name)
            if observed is None:
                continue
            data.thetas.append(theta.copy())
            data.frames.append(observed.frame)
    data.t_collect = clock.elapsed - t_start
    return data


def estimate_base_frame(data: CalibrationData, kins: Robot) -> Frame:
    """
    TODO: implement.

    With the calibration body's frame being exactly F_ee, every sample
    satisfies  F_ee,j = F_X * kins.fwd_kins(theta_j)  for one constant
    unknown F_X (the robot base expressed in the tracker's frame). Estimate
    F_X from all samples (your average_frames may help).

    input:
        data - CalibrationData
        kins - the kinematics to use (the nominal Robot at first; later your
            ImprovedKinematics)
    output: F_X
    """
    if len(data) == 0:
        raise ValueError("estimate_base_frame: no samples")
    return average_frames([F * kins.fwd_kins(th).inv() for th, F in zip(data.thetas, data.frames)])
